import sys

for i in sys.path :
    print(i)