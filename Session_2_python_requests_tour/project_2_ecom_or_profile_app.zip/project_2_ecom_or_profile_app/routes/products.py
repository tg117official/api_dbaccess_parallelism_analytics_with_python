# routes/products.py
from flask import Blueprint, jsonify
from services.file_utils import load_json

products_bp = Blueprint('products', __name__)

@products_bp.route('/products', methods=['GET'])
def list_products():
    products = load_json('data/products.json')
    return jsonify(products)
