# routes/profiles.py
from flask import Blueprint, session, request, jsonify
from services.profile_service import get_profile_by_username, update_profile

profiles_bp = Blueprint('profiles', __name__)

@profiles_bp.route('/my_profile', methods=['GET'])
def view_my_profile():
    username = session.get('username')
    if not username:
        return "Login required", 401

    profile = get_profile_by_username(username)
    return jsonify(profile or {"error": "Profile not found"})

@profiles_bp.route('/update_profile', methods=['POST'])
def update_my_profile():
    username = session.get('username')
    if not username:
        return "Login required", 401

    update_data = request.json
    success = update_profile(username, update_data)
    return jsonify({"updated": success})
